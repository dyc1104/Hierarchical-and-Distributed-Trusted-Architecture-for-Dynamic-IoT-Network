#### \#Peer发送退出请求给topo管理器

\*\* Event #186  t=30  block\_gen.peer\[0] (Peer, id=12)  on selfmsg ExitTimer (omnetpp::cMessage, id=7)

WARN: Peer\[0] LEAVE timing start at 30

INFO: Peer\[0] EXIT -> send PeerLeaveReq to topoMgr at 30

\*\* Event #187  t=30.011601821505  block\_gen.topoMgr (TopologyManager, id=17)  on PeerLeaveReq (omnetpp::PeerLeaveReq, id=917)

WARN: TopoMgr: send peer leave tx to orderer\_0, sid=peer\_0 peerId=0 at 30.011601821505

\*\* Event #188  t=30.022524780231  block\_gen.orderer\_0 (Orderer\_P, id=18)  on PeerLeaveVerify (omnetpp::VerifyMessage, id=919)

INFO: Orderer received txId=peer\_0 hash=3253832237564579118

INFO: Primary\[0] broadcast PrePrepare seq=9

INFO: \[Broadcast] time=30.022524780231 msg= outSize=2

INFO:   -> sending to out\[0] at t=30.022524780231

INFO:   -> sending to out\[1] at t=30.022524780231

\*\* Event #189  t=30.033582570074  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::PrePrepareMsg, id=928)

INFO: Node\[2] send Prepare seq=9

INFO: \[Broadcast] time=30.033582570074 msg= outSize=2

INFO:   -> sending to out\[0] at t=30.033582570074

INFO:   -> sending to out\[1] at t=30.033582570074



#### \#退出信息上链共识

\*\* Event #190  t=30.034108230298  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::PrePrepareMsg, id=925)

INFO: Node\[1] send Prepare seq=9

INFO: \[Broadcast] time=30.034108230298 msg= outSize=2

INFO:   -> sending to out\[0] at t=30.034108230298

INFO:   -> sending to out\[1] at t=30.034108230298

\*\* Event #191  t=30.04436813966  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::PrepareMsg, id=936)

INFO: Node\[1] collected enough Prepare, send Commit seq=9

INFO: a new block generated!

INFO: Block\_height:9

WARN: Node\[1] FINALIZE seq=9 ✅ quorum=1 digest=3253832237564579118 state=2

INFO: \[BroadcastToPeers] t=30.04436813966 msg=block\_broadcast\_to\_peers outSize=2

INFO:   -> send to peer via out\[0]

INFO:   -> send to peer via out\[1]

INFO: \[Broadcast] time=30.04436813966 msg= outSize=2

INFO:   -> sending to out\[0] at t=30.04436813966

INFO:   -> sending to out\[1] at t=30.04436813966

\*\* Event #192  t=30.044542524417  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::PrepareMsg, id=933)

INFO: Node\[0] collected enough Prepare, send Commit seq=9

INFO: a new block generated!

INFO: Block\_height:9

WARN: Node\[0] FINALIZE seq=9 ✅ quorum=1 digest=3253832237564579118 state=2

INFO: \[BroadcastToPeers] t=30.044542524417 msg=block\_broadcast\_to\_peers outSize=2

INFO:   -> send to peer via out\[0]

INFO:   -> send to peer via out\[1]

INFO:   -> sendDirect to topoMgr via gate 'in' (5ms)

INFO: \[Broadcast] time=30.044542524417 msg= outSize=2

INFO:   -> sending to out\[0] at t=30.044542524417

INFO:   -> sending to out\[1] at t=30.044542524417

\*\* Event #193  t=30.045244319426  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::PrepareMsg, id=944)

INFO: Node\[2] collected enough Prepare, send Commit seq=9

INFO: a new block generated!

INFO: Block\_height:9

WARN: Node\[2] FINALIZE seq=9 ✅ quorum=1 digest=3253832237564579118 state=2

INFO: \[BroadcastToPeers] t=30.045244319426 msg=block\_broadcast\_to\_peers outSize=1

INFO:   -> send to peer via out\[0]

INFO: \[Broadcast] time=30.045244319426 msg= outSize=2

INFO:   -> sending to out\[0] at t=30.045244319426

INFO:   -> sending to out\[1] at t=30.045244319426

\*\* Event #194  t=30.045732567751  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::PrepareMsg, id=941)

\*\* Event #195  t=30.054963208871  block\_gen.peer\[1] (Peer, id=13)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=953)

INFO: Peer\[1] received BlockMsg: blockNum=9 ts=30.04436813966 reportSender=peer\_0

INFO: a new block generated!

INFO: Block\_height:9

WARN: Peer\[1] no verifyStartTime found for senderID=peer\_0 (cannot compute E2E)

INFO: Peer\[1] updated local ledger, new height=9 (from BlockMsg.blockNum=9)

\*\* Event #196  t=30.055087837006  block\_gen.peer\[3] (Peer, id=15)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=974)

INFO: Peer\[3] received BlockMsg: blockNum=9 ts=30.044542524417 reportSender=peer\_0

INFO: a new block generated!

INFO: Block\_height:9

WARN: Peer\[3] no verifyStartTime found for senderID=peer\_0 (cannot compute E2E)

INFO: Peer\[3] updated local ledger, new height=9 (from BlockMsg.blockNum=9)

\*\* Event #197  t=30.055311287833  block\_gen.peer\[0] (Peer, id=12)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=971)

INFO: Peer\[0] received BlockMsg: blockNum=9 ts=30.044542524417 reportSender=peer\_0

INFO: a new block generated!

INFO: Block\_height:9

WARN: Peer\[0] no verifyStartTime found for senderID=peer\_0 (cannot compute E2E)

INFO: Peer\[0] updated local ledger, new height=9 (from BlockMsg.blockNum=9)

\*\* Event #198  t=30.055323469883  block\_gen.peer\[4] (Peer, id=16)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=956)

INFO: Peer\[4] received BlockMsg: blockNum=9 ts=30.04436813966 reportSender=peer\_0

INFO: a new block generated!

INFO: Block\_height:9

WARN: Peer\[4] no verifyStartTime found for senderID=peer\_0 (cannot compute E2E)

INFO: Peer\[4] updated local ledger, new height=9 (from BlockMsg.blockNum=9)

\*\* Event #199  t=30.055357745377  block\_gen.peer\[2] (Peer, id=14)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=992)

INFO: Peer\[2] received BlockMsg: blockNum=9 ts=30.045244319426 reportSender=peer\_0

INFO: a new block generated!

INFO: Block\_height:9

WARN: Peer\[2] no verifyStartTime found for senderID=peer\_0 (cannot compute E2E)

INFO: Peer\[2] updated local ledger, new height=9 (from BlockMsg.blockNum=9)

\*\* Event #200  t=30.055504228788  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::CommitMsg, id=962)

\*\* Event #201  t=30.055583479378  block\_gen.topoMgr (TopologyManager, id=17)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=977)

INFO: a new block generated!

INFO: Block\_height:9

INFO: TopoMgr record: dev\[0] left (was under peer\[0])

WARN: TopoMgr: trigger dev\[0] ReJoin due to peer\[0] leave

\*\* Event #202  t=30.05560031426  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::CommitMsg, id=983)

\*\* Event #203  t=30.055992477113  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::CommitMsg, id=959)

\*\* Event #204  t=30.056029889012  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::CommitMsg, id=998)

\*\* Event #205  t=30.056125974484  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::CommitMsg, id=980)

\*\* Event #206  t=30.056204273769  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::CommitMsg, id=995)



#### \#共识完成后，通知device重新加入，信息会告诉相信device最近的Peer

\*\* Event #207  t=30.066941238445  block\_gen.dev\[0] (device, id=2)  on ReJoin (omnetpp::ReJoin, id=1008)

WARN: Device\[0] got ReJoin at 30.066941238445, will re-send JoinReq

INFO: 8897465151183562813

INFO: SignData: Successfully signed the hash value. Signature size: 256 bytes.

INFO: Generated Signature (hex): 8e3baf3fc7b49e9de1aea478fb64143612500a10db627784879e2b627fc45340ae27bd7b1de987e3a4291afe8a5b6785c0ceaf7fcd9fb3d0c0c9cea32a0c0ce79e3c6d869d8d1e4bb6d0ce322803bcf1633073b82a9a82ca0e95d705388f2fbdd3b340a3d2344beb1fdc077b949dda42008399cc81092ad532b1bda417a76fafb128d43e7b970f21a3bb3435ca02d735a7b4a2330182da0b5feec0543eeb817c348e4f899937f772203f0522335529efbc1e5ee1307200b21f385edd8a91a3b7877d24147e9fcddf27ab8c8d9ba8ad6df888c078bd25154820f87e554eed09a39d63523046943693e937ab05c79588876f63c9d024121d919c6a3fc1fe3825a5

INFO: Successfully extracted public key in PEM format.



#### \#通知Peer退出成功

\*\* Event #208  t=30.067144537729  block\_gen.peer\[0] (Peer, id=12)  on PeerLeaveAck (omnetpp::PeerLeaveAck, id=1007)

WARN: Peer\[0] leave SUCCESS at 30.055583479378 sid=peer\_0

WARN: Peer\[0] LEAVE time (req->ack) = 0.067144537729



#### \#Peer发送重新加入信息，topo管理器绑定相关信息（device公钥信息，device对应的peer）

\*\* Event #209  t=30.077177787293  block\_gen.topoMgr (TopologyManager, id=17)  on JoinReq (omnetpp::JoinReq, id=1010)

INFO: TopoMgr record: dev\[0] -> peer\[1]

INFO: TopoMgr: DealJoin real=8.8561e-05s scale=1 simDelay=0.000088561 (device=0 -> peer=1)

\*\* Event #210  t=30.077266348293  block\_gen.topoMgr (TopologyManager, id=17)  on selfmsg DealJoinDoneEvent (DealJoinDoneEvent, id=1015)

INFO: TopoMgr: (after cpuDelay) send JoinVerifyReq dev=0 -> peer\[1]

\*\* Event #211  t=30.088707613596  block\_gen.peer\[1] (Peer, id=13)  on JoinVerifyReq (omnetpp::JoinVerifyReq, id=1017)

INFO: RSA Signature verified successfully.

INFO: Peer\[1] received JoinVerifyReq for device 0, schedule verifyDone at 30.089040478596

\*\* Event #212  t=30.089040478596  block\_gen.peer\[1] (Peer, id=13)  on selfmsg joinVerifyDone (JoinVerifyEvent, id=1021)

INFO: RSA Signature verified successfully.

INFO: Peer\[1] join verify done for device 0 verified=1 -> send VerifyMessage(state=1)

INFO: 3259961468078356822

INFO: SignData: Successfully signed the hash value. Signature size: 256 bytes.

INFO: Generated Signature (hex): 4fe54a836834cb8386a3f610b8538de77cb4a7af2dfc5af591c690806776c19afad1eeec39b3d05075814b58f2dd60c75ca61e8330fc04731ce8cf6e4a550f75d70f328d7fbfb3fbe210c1c47fa1bd740a2d62518743e78dc65cd2189f748015a2f8292391cf1a709435b978bf3adb7135b00d3f0843609c0dd42dda49b44aa17a27f9e04c741e2b2a422166312202d4b540826295e09b8d923dc954a5fc2c6bb97b23f68e1c39928ed20bd209e971a08a8bdd0e2b9ea7b1d84a6381b30f991f3ff6b468699b377cba95f1a2612f3dea79f5e523fe85274c32c58aec697c31e68688dcf169ff94977ec0620bbba48061da121a13908a4c175043964dc75694a0

INFO: Successfully extracted public key in PEM format.

\*\* Event #213  t=30.099915653016  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on VerifyMessage (omnetpp::VerifyMessage, id=1023)

INFO: Orderer received txId=device\_0\_0 hash=8897465151183562813

INFO: Node\[1] forward Report to Primary via orderout\[0], sender=device\_0\_0 hash=8897465151183562813

\*\* Event #214  t=30.10032032063  block\_gen.dev\[0] (device, id=2)  on JoinVerifyRsp (omnetpp::JoinVerifyRsp, id=1027)

INFO: RSA Signature verified successfully.

INFO: Device\[0] Verify Peer\[1] SUCCESS. delay = 0.00909221

\*\* Event #215  t=30.111539990469  block\_gen.orderer\_0 (Orderer\_P, id=18)  on report\_to\_primary (omnetpp::VerifyMessage, id=1031)

INFO: Orderer received txId=device\_0\_0 hash=8897465151183562813

INFO: Primary\[0] broadcast PrePrepare seq=10

INFO: \[Broadcast] time=30.111539990469 msg= outSize=2

INFO:   -> sending to out\[0] at t=30.111539990469

INFO:   -> sending to out\[1] at t=30.111539990469

\*\* Event #216  t=30.122597780312  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::PrePrepareMsg, id=1041)

INFO: Node\[2] send Prepare seq=10

INFO: \[Broadcast] time=30.122597780312 msg= outSize=2

INFO:   -> sending to out\[0] at t=30.122597780312

INFO:   -> sending to out\[1] at t=30.122597780312

\*\* Event #217  t=30.123123440536  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::PrePrepareMsg, id=1038)

INFO: Node\[1] send Prepare seq=10

INFO: \[Broadcast] time=30.123123440536 msg= outSize=2

INFO:   -> sending to out\[0] at t=30.123123440536

INFO:   -> sending to out\[1] at t=30.123123440536

\*\* Event #218  t=30.133383349898  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::PrepareMsg, id=1049)

INFO: Node\[1] collected enough Prepare, send Commit seq=10

INFO: a new block generated!

INFO: Block\_height:10

WARN: Node\[1] FINALIZE seq=10 ✅ quorum=1 digest=8897465151183562813 state=1

INFO: \[BroadcastToPeers] t=30.133383349898 msg=block\_broadcast\_to\_peers outSize=2

INFO:   -> send to peer via out\[0]

INFO:   -> send to peer via out\[1]

INFO: \[Broadcast] time=30.133383349898 msg= outSize=2

INFO:   -> sending to out\[0] at t=30.133383349898

INFO:   -> sending to out\[1] at t=30.133383349898

\*\* Event #219  t=30.133557734655  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::PrepareMsg, id=1046)

INFO: Node\[0] collected enough Prepare, send Commit seq=10

INFO: a new block generated!

INFO: Block\_height:10

WARN: Node\[0] FINALIZE seq=10 ✅ quorum=1 digest=8897465151183562813 state=1

INFO: \[BroadcastToPeers] t=30.133557734655 msg=block\_broadcast\_to\_peers outSize=2

INFO:   -> send to peer via out\[0]

INFO:   -> send to peer via out\[1]

INFO:   -> sendDirect to topoMgr via gate 'in' (5ms)

INFO: \[Broadcast] time=30.133557734655 msg= outSize=2

INFO:   -> sending to out\[0] at t=30.133557734655

INFO:   -> sending to out\[1] at t=30.133557734655

\*\* Event #220  t=30.134259529664  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::PrepareMsg, id=1057)

INFO: Node\[2] collected enough Prepare, send Commit seq=10

INFO: a new block generated!

INFO: Block\_height:10

WARN: Node\[2] FINALIZE seq=10 ✅ quorum=1 digest=8897465151183562813 state=1

INFO: \[BroadcastToPeers] t=30.134259529664 msg=block\_broadcast\_to\_peers outSize=1

INFO:   -> send to peer via out\[0]

INFO: \[Broadcast] time=30.134259529664 msg= outSize=2

INFO:   -> sending to out\[0] at t=30.134259529664

INFO:   -> sending to out\[1] at t=30.134259529664

\*\* Event #221  t=30.134747777989  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::PrepareMsg, id=1054)

\*\* Event #222  t=30.143978419109  block\_gen.peer\[1] (Peer, id=13)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=1066)

INFO: Peer\[1] received BlockMsg: blockNum=10 ts=30.133383349898 reportSender=device\_0\_0

INFO: a new block generated!

INFO: Block\_height:10

WARN: Peer\[1] no verifyStartTime found for senderID=device\_0\_0 (cannot compute E2E)

INFO: Peer\[1] updated local ledger, new height=10 (from BlockMsg.blockNum=10)

INFO: Peer\[1]: ledger updated for join tx sender=device\_0\_0 -> notify dev\[0] JOIN success

\*\* Event #223  t=30.144103047244  block\_gen.peer\[3] (Peer, id=15)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=1087)

INFO: Peer\[3] received BlockMsg: blockNum=10 ts=30.133557734655 reportSender=device\_0\_0

INFO: a new block generated!

INFO: Block\_height:10

WARN: Peer\[3] no verifyStartTime found for senderID=device\_0\_0 (cannot compute E2E)

INFO: Peer\[3] updated local ledger, new height=10 (from BlockMsg.blockNum=10)

\*\* Event #224  t=30.144326498071  block\_gen.peer\[0] (Peer, id=12)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=1084)

\*\* Event #225  t=30.144338680121  block\_gen.peer\[4] (Peer, id=16)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=1069)

INFO: Peer\[4] received BlockMsg: blockNum=10 ts=30.133383349898 reportSender=device\_0\_0

INFO: a new block generated!

INFO: Block\_height:10

WARN: Peer\[4] no verifyStartTime found for senderID=device\_0\_0 (cannot compute E2E)

INFO: Peer\[4] updated local ledger, new height=10 (from BlockMsg.blockNum=10)

\*\* Event #226  t=30.144372955615  block\_gen.peer\[2] (Peer, id=14)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=1105)

INFO: Peer\[2] received BlockMsg: blockNum=10 ts=30.134259529664 reportSender=device\_0\_0

INFO: a new block generated!

INFO: Block\_height:10

WARN: Peer\[2] no verifyStartTime found for senderID=device\_0\_0 (cannot compute E2E)

INFO: Peer\[2] updated local ledger, new height=10 (from BlockMsg.blockNum=10)

\*\* Event #227  t=30.144519439026  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::CommitMsg, id=1075)

\*\* Event #228  t=30.144615524498  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::CommitMsg, id=1096)

\*\* Event #229  t=30.144721774237  block\_gen.topoMgr (TopologyManager, id=17)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=1090)

INFO: a new block generated!

INFO: Block\_height:10

\*\* Event #230  t=30.145007687351  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::CommitMsg, id=1072)

\*\* Event #231  t=30.14504509925  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::CommitMsg, id=1111)

\*\* Event #232  t=30.145141184722  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::CommitMsg, id=1093)

\*\* Event #233  t=30.145219484007  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::CommitMsg, id=1108)

\*\* Event #234  t=30.15426512568  block\_gen.dev\[0] (device, id=2)  on JoinAck (omnetpp::JoinAck, id=1115)

WARN: Device\[0] REJOIN time=0.087323887235

INFO: Device\[0] got JoinAck success=1 at 30.143978419109



