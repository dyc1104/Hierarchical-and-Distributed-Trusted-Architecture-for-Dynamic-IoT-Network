#### \#device发送退出请求给Peer

\*\* Event #235  t=50  block\_gen.dev\[0] (device, id=2)  on selfmsg ExitTimer (omnetpp::cMessage, id=2)

INFO: Device\[0] send LeaveReq via out\[0] at 50

\*\* Event #236  t=50.011074746456  block\_gen.peer\[1] (Peer, id=13)  on LeaveReq (omnetpp::LeaveReq, id=1120)

INFO: Peer\[1] LeaveReq for deviceId=0 senderID=device\_0\_0 -> send VerifyMessage(state=2) to mapped orderer via out\[0]

\*\* Event #237  t=50.021949920876  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on VerifyMessage (omnetpp::VerifyMessage, id=1122)

INFO: Orderer received txId=device\_0\_0 hash=8897465151183562813



#### \#退出信息上链

INFO: Node\[1] forward Report to Primary via orderout\[0], sender=device\_0\_0 hash=8897465151183562813

\*\* Event #238  t=50.033574258329  block\_gen.orderer\_0 (Orderer\_P, id=18)  on report\_to\_primary (omnetpp::VerifyMessage, id=1126)

INFO: Orderer received txId=device\_0\_0 hash=8897465151183562813

INFO: Primary\[0] broadcast PrePrepare seq=11

INFO: \[Broadcast] time=50.033574258329 msg= outSize=2

INFO:   -> sending to out\[0] at t=50.033574258329

INFO:   -> sending to out\[1] at t=50.033574258329

\*\* Event #239  t=50.044632048172  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::PrePrepareMsg, id=1135)

INFO: Node\[2] send Prepare seq=11

INFO: \[Broadcast] time=50.044632048172 msg= outSize=2

INFO:   -> sending to out\[0] at t=50.044632048172

INFO:   -> sending to out\[1] at t=50.044632048172

\*\* Event #240  t=50.045157708396  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::PrePrepareMsg, id=1132)

INFO: Node\[1] send Prepare seq=11

INFO: \[Broadcast] time=50.045157708396 msg= outSize=2

INFO:   -> sending to out\[0] at t=50.045157708396

INFO:   -> sending to out\[1] at t=50.045157708396

\*\* Event #241  t=50.055417617758  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::PrepareMsg, id=1143)

INFO: Node\[1] collected enough Prepare, send Commit seq=11

INFO: a new block generated!

INFO: Block\_height:11

WARN: Node\[1] FINALIZE seq=11 ✅ quorum=1 digest=8897465151183562813 state=2

INFO: \[BroadcastToPeers] t=50.055417617758 msg=block\_broadcast\_to\_peers outSize=2

INFO:   -> send to peer via out\[0]

INFO:   -> send to peer via out\[1]

INFO: \[Broadcast] time=50.055417617758 msg= outSize=2

INFO:   -> sending to out\[0] at t=50.055417617758

INFO:   -> sending to out\[1] at t=50.055417617758

\*\* Event #242  t=50.055592002515  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::PrepareMsg, id=1140)

INFO: Node\[0] collected enough Prepare, send Commit seq=11

INFO: a new block generated!

INFO: Block\_height:11

WARN: Node\[0] FINALIZE seq=11 ✅ quorum=1 digest=8897465151183562813 state=2

INFO: \[BroadcastToPeers] t=50.055592002515 msg=block\_broadcast\_to\_peers outSize=2

INFO:   -> send to peer via out\[0]

INFO:   -> send to peer via out\[1]

INFO:   -> sendDirect to topoMgr via gate 'in' (5ms)

INFO: \[Broadcast] time=50.055592002515 msg= outSize=2

INFO:   -> sending to out\[0] at t=50.055592002515

INFO:   -> sending to out\[1] at t=50.055592002515

\*\* Event #243  t=50.056293797524  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::PrepareMsg, id=1151)

INFO: Node\[2] collected enough Prepare, send Commit seq=11

INFO: a new block generated!

INFO: Block\_height:11

WARN: Node\[2] FINALIZE seq=11 ✅ quorum=1 digest=8897465151183562813 state=2

INFO: \[BroadcastToPeers] t=50.056293797524 msg=block\_broadcast\_to\_peers outSize=1

INFO:   -> send to peer via out\[0]

INFO: \[Broadcast] time=50.056293797524 msg= outSize=2

INFO:   -> sending to out\[0] at t=50.056293797524

INFO:   -> sending to out\[1] at t=50.056293797524

\*\* Event #244  t=50.056782045849  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::PrepareMsg, id=1148)

\*\* Event #245  t=50.066012686969  block\_gen.peer\[1] (Peer, id=13)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=1160)

INFO: Peer\[1] received BlockMsg: blockNum=11 ts=50.055417617758 reportSender=device\_0\_0

INFO: a new block generated!

INFO: Block\_height:11

WARN: Peer\[1] no verifyStartTime found for senderID=device\_0\_0 (cannot compute E2E)

INFO: Peer\[1] updated local ledger, new height=11 (from BlockMsg.blockNum=11)

INFO: Peer\[1]: ledger updated for LEAVE tx sender=device\_0\_0 -> notify dev\[0] LEAVE ack

\*\* Event #246  t=50.066137315104  block\_gen.peer\[3] (Peer, id=15)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=1181)

INFO: Peer\[3] received BlockMsg: blockNum=11 ts=50.055592002515 reportSender=device\_0\_0

INFO: a new block generated!

INFO: Block\_height:11

WARN: Peer\[3] no verifyStartTime found for senderID=device\_0\_0 (cannot compute E2E)

INFO: Peer\[3] updated local ledger, new height=11 (from BlockMsg.blockNum=11)

\*\* Event #247  t=50.066360765931  block\_gen.peer\[0] (Peer, id=12)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=1178)

\*\* Event #248  t=50.066372947981  block\_gen.peer\[4] (Peer, id=16)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=1163)

INFO: Peer\[4] received BlockMsg: blockNum=11 ts=50.055417617758 reportSender=device\_0\_0

INFO: a new block generated!

INFO: Block\_height:11

WARN: Peer\[4] no verifyStartTime found for senderID=device\_0\_0 (cannot compute E2E)

INFO: Peer\[4] updated local ledger, new height=11 (from BlockMsg.blockNum=11)

\*\* Event #249  t=50.066407223475  block\_gen.peer\[2] (Peer, id=14)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=1199)

INFO: Peer\[2] received BlockMsg: blockNum=11 ts=50.056293797524 reportSender=device\_0\_0

INFO: a new block generated!

INFO: Block\_height:11

WARN: Peer\[2] no verifyStartTime found for senderID=device\_0\_0 (cannot compute E2E)

INFO: Peer\[2] updated local ledger, new height=11 (from BlockMsg.blockNum=11)

\*\* Event #250  t=50.066553706886  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::CommitMsg, id=1169)

\*\* Event #251  t=50.066649792358  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::CommitMsg, id=1190)

\*\* Event #252  t=50.067041955211  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::CommitMsg, id=1166)

\*\* Event #253  t=50.06707936711  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::CommitMsg, id=1205)

\*\* Event #254  t=50.067175452582  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::CommitMsg, id=1187)

\*\* Event #255  t=50.067253751867  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::CommitMsg, id=1202)

\*\* Event #256  t=50.067481340352  block\_gen.topoMgr (TopologyManager, id=17)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=1184)

INFO: a new block generated!

INFO: Block\_height:11



#### \#返回退出确认

\*\* Event #257  t=50.07752991821  block\_gen.dev\[0] (device, id=2)  on LeaveAck (omnetpp::LeaveAck, id=1209)

WARN: Device\[0] LEAVE time(req->ack)=0.066012686969

INFO: Device\[0] got LeaveAck at 50.066012686969 sender=device\_0\_0

