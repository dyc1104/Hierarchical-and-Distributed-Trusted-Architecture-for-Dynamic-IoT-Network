#### \#device发送加入信息给topo管理器

\*\* Event #138  t=10  block\_gen.dev\[0] (device, id=2)  on selfmsg JoinTimer (omnetpp::cMessage, id=0)

INFO: 4119869281875228436

INFO: SignData: Successfully signed the hash value. Signature size: 256 bytes.

INFO: Generated Signature (hex): 67eac7276604fbe19493e719201fd74b03445c92e0506ebda2c99e0961591ecf51b84fa995ccd6d5524a3850f517b01b1e8a079aff58615a8f65d954f3b9dadad8c1950db42784fdd94b8948769c81126b6c94b4d590bc388b82dc3435f7a94504a6857f5ed5c5fc5d148f404a7089a0b2d1c3f290fa022940f1e82cbe7613c703ad32b50e4675cf7c7cfce12f8df107e62a3c696d0dad8d93b84f8c50d3b23abd98fb742e8559c1f84fcba8ef1542e2e08ecc08325f1ebbe53953aa6cacf860474bce96a7f362eb2aea750829f01de225f2476aa05fe20a15ee1b6314b16d219dcb9fdb50b62fdbf2e8af644b80c9028f02881475a62994afbe5a94a50bb6c0

INFO: Successfully extracted public key in PEM format.

INFO: Device\[0]: send JoinReq at 10

\*\* Event #139  t=10.011556313514  block\_gen.topoMgr (TopologyManager, id=17)  on JoinReq (omnetpp::JoinReq, id=718)

INFO: TopoMgr record: dev\[0] -> peer\[0]

INFO: TopoMgr: DealJoin real=6.1363e-05s scale=1 simDelay=0.000061363 (device=0 -> peer=0)

\*\* Event #140  t=10.011617676514  block\_gen.topoMgr (TopologyManager, id=17)  on selfmsg DealJoinDoneEvent (DealJoinDoneEvent, id=723)



#### \#topo管理器评估性能，转发验证请求给device最近的Peer

INFO: TopoMgr: (after cpuDelay) send JoinVerifyReq dev=0 -> peer\[0]

\*\* Event #141  t=10.021898378069  block\_gen.peer\[0] (Peer, id=12)  on JoinVerifyReq (omnetpp::JoinVerifyReq, id=725)

INFO: RSA Signature verified successfully.

INFO: Peer\[0] received JoinVerifyReq for device 0, schedule verifyDone at 10.022150645069

\*\* Event #142  t=10.022150645069  block\_gen.peer\[0] (Peer, id=12)  on selfmsg joinVerifyDone (JoinVerifyEvent, id=729)

INFO: RSA Signature verified successfully.

WARN: Peer\[0] bind senderID=device\_0\_0 to pubkey (first seen)

INFO: Peer\[0] join verify done for device 0 verified=1 -> send VerifyMessage(state=1)

INFO: 1433081945494864629

INFO: SignData: Successfully signed the hash value. Signature size: 256 bytes.

INFO: Generated Signature (hex): 5c35288684b93829c61ddfd0e151544a63be43766298395baa8d176a12aecd452c959b5e9ddfe6783e00a23933fb60362754ee92484a78cd2b246224f2bc2905ef7231df337a4b64d38c4621cdc1f62aceb6360a07f307d7a8f1ea4d69a10c826a527141016b6df94dfb3eeb9c0561a4406b83d519794b40f007ac9ff1a40ace3fa069d7f08df567819c0f643a809cc1166c1a87514a355554c3ba5ffb061efe2d40f0278eca02a2bc423dff2034a6541e0757657b1d2f7de3610b87e0dffd9eb852bb1f39e3b1fb822ba70858833f27d518d5891cf586e48c6c36d7f8d552ae718ad4e07b9df7fc76238f4843699c145688601a01cf0fdd6f72f5077cb4390a

INFO: Successfully extracted public key in PEM format.

\*\* Event #143  t=10.033442433299  block\_gen.orderer\_0 (Orderer\_P, id=18)  on VerifyMessage (omnetpp::VerifyMessage, id=731)

INFO: Orderer received txId=device\_0\_0 hash=4119869281875228436

INFO: Primary\[0] broadcast PrePrepare seq=7

INFO: \[Broadcast] time=10.033442433299 msg= outSize=2

INFO:   -> sending to out\[0] at t=10.033442433299

INFO:   -> sending to out\[1] at t=10.033442433299

\*\* Event #144  t=10.03389066936  block\_gen.dev\[0] (device, id=2)  on JoinVerifyRsp (omnetpp::JoinVerifyRsp, id=735)

INFO: RSA Signature verified successfully.

INFO: Device\[0] Verify Peer\[0] SUCCESS. delay = 0.00909221



#### \#验证结果上链

\*\* Event #145  t=10.044500223142  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::PrePrepareMsg, id=744)

INFO: Node\[2] send Prepare seq=7

INFO: \[Broadcast] time=10.044500223142 msg= outSize=2

INFO:   -> sending to out\[0] at t=10.044500223142

INFO:   -> sending to out\[1] at t=10.044500223142

\*\* Event #146  t=10.045025883366  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::PrePrepareMsg, id=741)

INFO: Node\[1] send Prepare seq=7

INFO: \[Broadcast] time=10.045025883366 msg= outSize=2

INFO:   -> sending to out\[0] at t=10.045025883366

INFO:   -> sending to out\[1] at t=10.045025883366

\*\* Event #147  t=10.055285792728  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::PrepareMsg, id=753)

INFO: Node\[1] collected enough Prepare, send Commit seq=7

INFO: a new block generated!

INFO: Block\_height:7

WARN: Node\[1] FINALIZE seq=7 ✅ quorum=1 digest=4119869281875228436 state=1

INFO: \[BroadcastToPeers] t=10.055285792728 msg=block\_broadcast\_to\_peers outSize=2

INFO:   -> send to peer via out\[0]

INFO:   -> send to peer via out\[1]

INFO: \[Broadcast] time=10.055285792728 msg= outSize=2

INFO:   -> sending to out\[0] at t=10.055285792728

INFO:   -> sending to out\[1] at t=10.055285792728

\*\* Event #148  t=10.055460177485  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::PrepareMsg, id=750)

INFO: Node\[0] collected enough Prepare, send Commit seq=7

INFO: a new block generated!

INFO: Block\_height:7

WARN: Node\[0] FINALIZE seq=7 ✅ quorum=1 digest=4119869281875228436 state=1

INFO: \[BroadcastToPeers] t=10.055460177485 msg=block\_broadcast\_to\_peers outSize=2

INFO:   -> send to peer via out\[0]

INFO:   -> send to peer via out\[1]

INFO:   -> sendDirect to topoMgr via gate 'in' (5ms)

INFO: \[Broadcast] time=10.055460177485 msg= outSize=2

INFO:   -> sending to out\[0] at t=10.055460177485

INFO:   -> sending to out\[1] at t=10.055460177485

\*\* Event #149  t=10.056161972494  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::PrepareMsg, id=761)

INFO: Node\[2] collected enough Prepare, send Commit seq=7

INFO: a new block generated!

INFO: Block\_height:7

WARN: Node\[2] FINALIZE seq=7 ✅ quorum=1 digest=4119869281875228436 state=1

INFO: \[BroadcastToPeers] t=10.056161972494 msg=block\_broadcast\_to\_peers outSize=1

INFO:   -> send to peer via out\[0]

INFO: \[Broadcast] time=10.056161972494 msg= outSize=2

INFO:   -> sending to out\[0] at t=10.056161972494

INFO:   -> sending to out\[1] at t=10.056161972494

\*\* Event #150  t=10.056650220819  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::PrepareMsg, id=758)

\*\* Event #151  t=10.065880861939  block\_gen.peer\[1] (Peer, id=13)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=770)

INFO: Peer\[1] received BlockMsg: blockNum=7 ts=10.055285792728 reportSender=device\_0\_0

INFO: a new block generated!

INFO: Block\_height:7

WARN: Peer\[1] no verifyStartTime found for senderID=device\_0\_0 (cannot compute E2E)

INFO: Peer\[1] updated local ledger, new height=7 (from BlockMsg.blockNum=7)

\*\* Event #152  t=10.066005490074  block\_gen.peer\[3] (Peer, id=15)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=791)

INFO: Peer\[3] received BlockMsg: blockNum=7 ts=10.055460177485 reportSender=device\_0\_0

INFO: a new block generated!

INFO: Block\_height:7

WARN: Peer\[3] no verifyStartTime found for senderID=device\_0\_0 (cannot compute E2E)

INFO: Peer\[3] updated local ledger, new height=7 (from BlockMsg.blockNum=7)

\*\* Event #153  t=10.066228940901  block\_gen.peer\[0] (Peer, id=12)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=788)

INFO: Peer\[0] received BlockMsg: blockNum=7 ts=10.055460177485 reportSender=device\_0\_0

INFO: a new block generated!

INFO: Block\_height:7

WARN: Peer\[0] no verifyStartTime found for senderID=device\_0\_0 (cannot compute E2E)

INFO: Peer\[0] updated local ledger, new height=7 (from BlockMsg.blockNum=7)

INFO: Peer\[0]: ledger updated for join tx sender=device\_0\_0 -> notify dev\[0] JOIN success

\*\* Event #154  t=10.066241122951  block\_gen.peer\[4] (Peer, id=16)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=773)

INFO: Peer\[4] received BlockMsg: blockNum=7 ts=10.055285792728 reportSender=device\_0\_0

INFO: a new block generated!

INFO: Block\_height:7

WARN: Peer\[4] no verifyStartTime found for senderID=device\_0\_0 (cannot compute E2E)

INFO: Peer\[4] updated local ledger, new height=7 (from BlockMsg.blockNum=7)

\*\* Event #155  t=10.066275398445  block\_gen.peer\[2] (Peer, id=14)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=809)

INFO: Peer\[2] received BlockMsg: blockNum=7 ts=10.056161972494 reportSender=device\_0\_0

INFO: a new block generated!

INFO: Block\_height:7

WARN: Peer\[2] no verifyStartTime found for senderID=device\_0\_0 (cannot compute E2E)

INFO: Peer\[2] updated local ledger, new height=7 (from BlockMsg.blockNum=7)

\*\* Event #156  t=10.066421881856  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::CommitMsg, id=779)

\*\* Event #157  t=10.066517967328  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::CommitMsg, id=800)

\*\* Event #158  t=10.066910130181  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::CommitMsg, id=776)

\*\* Event #159  t=10.06694754208  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::CommitMsg, id=815)

\*\* Event #160  t=10.067043627552  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::CommitMsg, id=797)

\*\* Event #161  t=10.067121926837  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::CommitMsg, id=812)

\*\* Event #162  t=10.067200351987  block\_gen.topoMgr (TopologyManager, id=17)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=794)

INFO: a new block generated!

INFO: Block\_height:7



#### \#上链结束，通知加入成功

\*\* Event #163  t=10.078186177587  block\_gen.dev\[0] (device, id=2)  on JoinAck (omnetpp::JoinAck, id=821)

INFO: Device\[0] JOIN time=0.078186177587

INFO: Device\[0] got JoinAck success=1 at 10.066228940901



