#### \#Peer开始加入生成报告和请求信息

\*\* Event #99  t=5  block\_gen.peer\[3] (Peer, id=15)  on selfmsg PeerJoinTimer (omnetpp::cMessage, id=20)

WARN: Peer\[3] JOIN timing start at 5

INFO: 5304606998832606857

INFO: SignData: Successfully signed the hash value. Signature size: 256 bytes.

INFO: Generated Signature (hex): 23940e8c3466732397b7e952208c865e49664cf8ac02012ed102c14742af64c0f8f1a0301322e7b040157ae21fb819087df5990cd93e127ecaa80de0cf0cf891039988fe7b36513550f1639a5636aa19dfc9b3e5dda2974ee58f2a2efa19362d7df1bb913d8004b5f577ea5336a4ba3b6a279fae50e19a95e000c357aa706a80d7ac981c0a72f7482fc3c93f92680ca2d86aef8fd92f4430f9ec92837a60c2facb160f07eff114e4e9b6f1125b4a177b9d2dac0747bad6d6c3f7cc56443c816704de48d38c692cb45971e7b6131bad1b97b1c8e68007e106be815082995a758797985b97af317db7451a28e726403231227873aa88152eebf417e5dac406321e

INFO: Successfully extracted public key in PEM format.



#### \#请求信息发送给topo管理器，topo管理器转发给较近的已加入peer节点验证

WARN: Peer\[3] send PeerJoinReq -> topoMgr at 5

\*\* Event #100  t=5.011296343753  block\_gen.topoMgr (TopologyManager, id=17)  on PeerJoinReq (omnetpp::PeerJoinReq, id=458)

INFO: TopoMgr: peer\[3] pending-join sid=peer\_3 real=1.875e-05s scale=1 simDelay=0.00001875

\*\* Event #101  t=5.011315093753  block\_gen.topoMgr (TopologyManager, id=17)  on selfmsg DealPeerJoinDoneEvent (DealPeerJoinDoneEvent, id=464)

INFO: TopoMgr: (after cpuDelay) forward PeerJoinVerifyReq(peerId=3) -> peer\[1]

\*\* Event #102  t=5.021355530551  block\_gen.peer\[1] (Peer, id=13)  on PeerJoinVerifyReq (omnetpp::PeerJoinVerifyReq, id=466)

INFO: RSA Signature verified successfully.

INFO: Peer\[1] received PeerJoinVerifyReq for peer 3, schedule verifyDone at 5.021618224551

\*\* Event #103  t=5.021618224551  block\_gen.peer\[1] (Peer, id=13)  on selfmsg peerJoinVerifyDone (PeerJoinVerifyEvent, id=470)

INFO: RSA Signature verified successfully.



#### \#验证后将验证结果上链

INFO: Peer\[1] peer-join verify done for peerId=3 senderID=peer\_3 verified=1 -> send VerifyMessage(state=1) to orderer via out\[0]

\*\* Event #104  t=5.032493398971  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on VerifyMessage (omnetpp::VerifyMessage, id=472)

INFO: Orderer received txId=peer\_3 hash=5304606998832606857

INFO: Node\[1] forward Report to Primary via orderout\[0], sender=peer\_3 hash=5304606998832606857

\*\* Event #105  t=5.044117736424  block\_gen.orderer\_0 (Orderer\_P, id=18)  on report\_to\_primary (omnetpp::VerifyMessage, id=476)

INFO: Orderer received txId=peer\_3 hash=5304606998832606857

INFO: Primary\[0] broadcast PrePrepare seq=6

INFO: \[Broadcast] time=5.044117736424 msg= outSize=2

INFO:   -> sending to out\[0] at t=5.044117736424

INFO:   -> sending to out\[1] at t=5.044117736424

\*\* Event #106  t=5.055175526267  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::PrePrepareMsg, id=485)

INFO: Node\[2] send Prepare seq=6

INFO: \[Broadcast] time=5.055175526267 msg= outSize=2

INFO:   -> sending to out\[0] at t=5.055175526267

INFO:   -> sending to out\[1] at t=5.055175526267

\*\* Event #107  t=5.055701186491  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::PrePrepareMsg, id=482)

INFO: Node\[1] send Prepare seq=6

INFO: \[Broadcast] time=5.055701186491 msg= outSize=2

INFO:   -> sending to out\[0] at t=5.055701186491

INFO:   -> sending to out\[1] at t=5.055701186491

\*\* Event #108  t=5.065961095853  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::PrepareMsg, id=493)

INFO: Node\[1] collected enough Prepare, send Commit seq=6

INFO: a new block generated!

INFO: Block\_height:6

WARN: Node\[1] FINALIZE seq=6 ✅ quorum=1 digest=5304606998832606857 state=1

INFO: \[BroadcastToPeers] t=5.065961095853 msg=block\_broadcast\_to\_peers outSize=2

INFO:   -> send to peer via out\[0]

INFO:   -> send to peer via out\[1]

INFO: \[Broadcast] time=5.065961095853 msg= outSize=2

INFO:   -> sending to out\[0] at t=5.065961095853

INFO:   -> sending to out\[1] at t=5.065961095853

\*\* Event #109  t=5.06613548061  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::PrepareMsg, id=490)

INFO: Node\[0] collected enough Prepare, send Commit seq=6

INFO: a new block generated!

INFO: Block\_height:6

WARN: Node\[0] FINALIZE seq=6 ✅ quorum=1 digest=5304606998832606857 state=1

INFO: \[BroadcastToPeers] t=5.06613548061 msg=block\_broadcast\_to\_peers outSize=2

INFO:   -> send to peer via out\[0]

INFO:   -> send to peer via out\[1]

INFO:   -> sendDirect to topoMgr via gate 'in' (5ms)

INFO: \[Broadcast] time=5.06613548061 msg= outSize=2

INFO:   -> sending to out\[0] at t=5.06613548061

INFO:   -> sending to out\[1] at t=5.06613548061

\*\* Event #110  t=5.066837275619  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::PrepareMsg, id=501)

INFO: Node\[2] collected enough Prepare, send Commit seq=6

INFO: a new block generated!

INFO: Block\_height:6

WARN: Node\[2] FINALIZE seq=6 ✅ quorum=1 digest=5304606998832606857 state=1

INFO: \[BroadcastToPeers] t=5.066837275619 msg=block\_broadcast\_to\_peers outSize=1

INFO:   -> send to peer via out\[0]

INFO: \[Broadcast] time=5.066837275619 msg= outSize=2

INFO:   -> sending to out\[0] at t=5.066837275619

INFO:   -> sending to out\[1] at t=5.066837275619

\*\* Event #111  t=5.067325523944  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::PrepareMsg, id=498)

\*\* Event #112  t=5.076556165064  block\_gen.peer\[1] (Peer, id=13)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=510)

INFO: Peer\[1] received BlockMsg: blockNum=6 ts=5.065961095853 reportSender=peer\_3

INFO: a new block generated!

INFO: Block\_height:6

WARN: Peer\[1] no verifyStartTime found for senderID=peer\_3 (cannot compute E2E)

INFO: Peer\[1] updated local ledger, new height=6 (from BlockMsg.blockNum=6)

\*\* Event #113  t=5.076680793199  block\_gen.peer\[3] (Peer, id=15)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=531)

\*\* Event #114  t=5.076871963685  block\_gen.topoMgr (TopologyManager, id=17)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=534)

INFO: a new block generated!

INFO: Block\_height:6



#### \#topo管理器更新账本，向待加入peer发送确认信息

WARN: TopoMgr: peer join confirmed on-chain, peer\[3] sid=peer\_3 at 5.076871963685

\*\* Event #115  t=5.076904244026  block\_gen.peer\[0] (Peer, id=12)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=528)

INFO: Peer\[0] received BlockMsg: blockNum=6 ts=5.06613548061 reportSender=peer\_3

INFO: a new block generated!

INFO: Block\_height:6

WARN: Peer\[0] no verifyStartTime found for senderID=peer\_3 (cannot compute E2E)

INFO: Peer\[0] updated local ledger, new height=6 (from BlockMsg.blockNum=6)

\*\* Event #116  t=5.076916426076  block\_gen.peer\[4] (Peer, id=16)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=513)

INFO: Peer\[4] received BlockMsg: blockNum=6 ts=5.065961095853 reportSender=peer\_3

INFO: a new block generated!

INFO: Block\_height:6

WARN: Peer\[4] no verifyStartTime found for senderID=peer\_3 (cannot compute E2E)

INFO: Peer\[4] updated local ledger, new height=6 (from BlockMsg.blockNum=6)

\*\* Event #117  t=5.07695070157  block\_gen.peer\[2] (Peer, id=14)  on block\_broadcast\_to\_peers (omnetpp::BlockMsg, id=549)

INFO: Peer\[2] received BlockMsg: blockNum=6 ts=5.066837275619 reportSender=peer\_3

INFO: a new block generated!

INFO: Block\_height:6

WARN: Peer\[2] no verifyStartTime found for senderID=peer\_3 (cannot compute E2E)

INFO: Peer\[2] updated local ledger, new height=6 (from BlockMsg.blockNum=6)

\*\* Event #118  t=5.077097184981  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::CommitMsg, id=519)

\*\* Event #119  t=5.077193270453  block\_gen.orderer\_np\[1] (Orderer\_nP, id=20)  on  (omnetpp::CommitMsg, id=540)

\*\* Event #120  t=5.077585433306  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::CommitMsg, id=516)

\*\* Event #121  t=5.077622845205  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::CommitMsg, id=555)

\*\* Event #122  t=5.077718930677  block\_gen.orderer\_np\[0] (Orderer\_nP, id=19)  on  (omnetpp::CommitMsg, id=537)

\*\* Event #123  t=5.077797229962  block\_gen.orderer\_0 (Orderer\_P, id=18)  on  (omnetpp::CommitMsg, id=552)



#### \#待加入Peer收到确认信息

\*\* Event #124  t=5.088537203371  block\_gen.peer\[3] (Peer, id=15)  on PeerJoinAck (omnetpp::PeerJoinAck, id=560)

WARN: Peer\[3] got PeerJoinAck success=1 at 5.076871963685



#### \#待加入Peer请求账本同步

INFO: Peer\[3] request ledger sync fromHeight=1 -> orderer\_0

\*\* Event #125  t=5.10045151368  block\_gen.orderer\_0 (Orderer\_P, id=18)  on SyncLedgerReq (omnetpp::SyncLedgerReq, id=564)

WARN: Orderer\[0] sync to peer\[3] fromHeight=1 lastHeight=6

\*\* Event #126  t=5.11245151368  block\_gen.peer\[3] (Peer, id=15)  on SyncBlockMsg (omnetpp::SyncBlockMsg, id=565)

WARN: Peer\[3] sync prep real=4.8497e-05s scale=1 -> simCpuDelay=0.000048497 block=1/6

\*\* Event #127  t=5.11245151368  block\_gen.peer\[3] (Peer, id=15)  on SyncBlockMsg (omnetpp::SyncBlockMsg, id=573)

\*\* Event #128  t=5.11245151368  block\_gen.peer\[3] (Peer, id=15)  on SyncBlockMsg (omnetpp::SyncBlockMsg, id=588)

\*\* Event #129  t=5.11245151368  block\_gen.peer\[3] (Peer, id=15)  on SyncBlockMsg (omnetpp::SyncBlockMsg, id=610)

\*\* Event #130  t=5.11245151368  block\_gen.peer\[3] (Peer, id=15)  on SyncBlockMsg (omnetpp::SyncBlockMsg, id=639)

\*\* Event #131  t=5.11245151368  block\_gen.peer\[3] (Peer, id=15)  on SyncBlockMsg (omnetpp::SyncBlockMsg, id=675)

\*\* Event #132  t=5.11250001068  block\_gen.peer\[3] (Peer, id=15)  on selfmsg SyncApplyDoneEvent (SyncApplyDoneEvent, id=711)

INFO: a new block generated!

INFO: Block\_height:1



#### \#账本同步

WARN: Peer\[3] synced block(applied) 1 / 6 at 5.11250001068

WARN: Peer\[3] sync prep real=6.5877e-05s scale=1 -> simCpuDelay=0.000065877 block=2/6

\*\* Event #133  t=5.11256588768  block\_gen.peer\[3] (Peer, id=15)  on selfmsg SyncApplyDoneEvent (SyncApplyDoneEvent, id=712)

INFO: a new block generated!

INFO: Block\_height:2

WARN: Peer\[3] synced block(applied) 2 / 6 at 5.11256588768

WARN: Peer\[3] sync prep real=9.5487e-05s scale=1 -> simCpuDelay=0.000095487 block=3/6

\*\* Event #134  t=5.11266137468  block\_gen.peer\[3] (Peer, id=15)  on selfmsg SyncApplyDoneEvent (SyncApplyDoneEvent, id=713)

INFO: a new block generated!

INFO: Block\_height:3

WARN: Peer\[3] synced block(applied) 3 / 6 at 5.11266137468

WARN: Peer\[3] sync prep real=0.000130755s scale=1 -> simCpuDelay=0.000130755 block=4/6

\*\* Event #135  t=5.11279212968  block\_gen.peer\[3] (Peer, id=15)  on selfmsg SyncApplyDoneEvent (SyncApplyDoneEvent, id=714)

INFO: a new block generated!

INFO: Block\_height:4

WARN: Peer\[3] synced block(applied) 4 / 6 at 5.11279212968

WARN: Peer\[3] sync prep real=0.000145468s scale=1 -> simCpuDelay=0.000145468 block=5/6

\*\* Event #136  t=5.11293759768  block\_gen.peer\[3] (Peer, id=15)  on selfmsg SyncApplyDoneEvent (SyncApplyDoneEvent, id=715)

INFO: a new block generated!

INFO: Block\_height:5

WARN: Peer\[3] synced block(applied) 5 / 6 at 5.11293759768

WARN: Peer\[3] sync prep real=0.000146118s scale=1 -> simCpuDelay=0.000146118 block=6/6

\*\* Event #137  t=5.11308371568  block\_gen.peer\[3] (Peer, id=15)  on selfmsg SyncApplyDoneEvent (SyncApplyDoneEvent, id=716)

INFO: a new block generated!

INFO: Block\_height:6

WARN: Peer\[3] synced block(applied) 6 / 6 at 5.11308371568

WARN: Peer\[3] full ledger sync DONE. height=6

WARN: Peer\[3] JOIN total time (req->syncDone) = 0.11308371568 (start=5, end=5.11308371568)



